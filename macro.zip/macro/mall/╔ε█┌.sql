-- Create table
create table D_MATCH_APPLY_INFO
(
  id                 VARCHAR2(32) not null,
  match_id           VARCHAR2(32) not null,
  match_type         CHAR(1) not null,
  team_id            VARCHAR2(32),
  real_name          VARCHAR2(100),
  user_phone         VARCHAR2(20),
  cert_id            VARCHAR2(32),
  cert_type          VARCHAR2(10),
  bank_card          VARCHAR2(32),
  card_type          VARCHAR2(10),
  gender             CHAR(1),
  other_param        VARCHAR2(2000),
  apply_create_date  VARCHAR2(10),
  apply_create_time  VARCHAR2(10),
  apply_success_date VARCHAR2(10),
  apply_success_time VARCHAR2(10),
  apply_channel      VARCHAR2(10),
  apply_state        CHAR(2),
  safe_orderno       VARCHAR2(50),
  emergency_name     VARCHAR2(20),
  emergency_phone    VARCHAR2(20),
  emergency_address  VARCHAR2(200),
  age                VARCHAR2(4),
  update_date_time   VARCHAR2(25),
  flag               VARCHAR2(2),
  region             VARCHAR2(100),
  community          VARCHAR2(100),
  head_flag          VARCHAR2(2),
  branch_flag        VARCHAR2(10),
  city               VARCHAR2(100),
  detail_address     VARCHAR2(300),
  assembly_address   VARCHAR2(100),
  assembly_date      VARCHAR2(100),
  apply_phone        VARCHAR2(20),
  match_code         VARCHAR2(2)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_APPLY_INFO
  is '赛事报名表';
-- Add comments to the columns 
comment on column D_MATCH_APPLY_INFO.id
  is 'id';
comment on column D_MATCH_APPLY_INFO.match_id
  is '赛事id';
comment on column D_MATCH_APPLY_INFO.match_type
  is '赛事类型 0:个人 1:团体';
comment on column D_MATCH_APPLY_INFO.team_id
  is '队伍id';
comment on column D_MATCH_APPLY_INFO.real_name
  is '用户姓名';
comment on column D_MATCH_APPLY_INFO.user_phone
  is '用户手机号';
comment on column D_MATCH_APPLY_INFO.cert_id
  is '证件号';
comment on column D_MATCH_APPLY_INFO.cert_type
  is '证件类型';
comment on column D_MATCH_APPLY_INFO.bank_card
  is '银行卡号';
comment on column D_MATCH_APPLY_INFO.card_type
  is '卡类型';
comment on column D_MATCH_APPLY_INFO.gender
  is '性别 0:男 1:女';
comment on column D_MATCH_APPLY_INFO.other_param
  is '个性化参数';
comment on column D_MATCH_APPLY_INFO.apply_create_date
  is '报名申请日期 yyyy-MM-dd';
comment on column D_MATCH_APPLY_INFO.apply_create_time
  is '报名申请时间 hh24:mi:ss';
comment on column D_MATCH_APPLY_INFO.apply_success_date
  is '报名成功日期 yyyy-MM-dd';
comment on column D_MATCH_APPLY_INFO.apply_success_time
  is '报名成功时间 hh24:mi:ss';
comment on column D_MATCH_APPLY_INFO.apply_channel
  is '报名渠道 缤纷:MLIFE  手机银行:BOC';
comment on column D_MATCH_APPLY_INFO.apply_state
  is '状态 00:报名成功 01:待支付报名费 02:待支付保险费
 04:组队申请中 05:组队申请失败 06:被队长移除队伍  07:退出队伍 09:退赛成功 10:报名取消';
comment on column D_MATCH_APPLY_INFO.safe_orderno
  is '保险订单号';
comment on column D_MATCH_APPLY_INFO.emergency_name
  is '紧急联系人姓名';
comment on column D_MATCH_APPLY_INFO.emergency_phone
  is '紧急联系人手机号';
comment on column D_MATCH_APPLY_INFO.emergency_address
  is '紧急联系人家庭地址';
comment on column D_MATCH_APPLY_INFO.age
  is '报名人员年龄';
comment on column D_MATCH_APPLY_INFO.update_date_time
  is '报名状态更新时间：yyyy-MM-dd hhmmss';
comment on column D_MATCH_APPLY_INFO.flag
  is '批量状态 01：待发送   02：修改个人信息  03：退赛     04：已发送';
comment on column D_MATCH_APPLY_INFO.region
  is '所属地区';
comment on column D_MATCH_APPLY_INFO.community
  is '所属社区';
comment on column D_MATCH_APPLY_INFO.head_flag
  is '队长标记   0 不是   1  是';
comment on column D_MATCH_APPLY_INFO.branch_flag
  is '领导临时要求增加的  ';
comment on column D_MATCH_APPLY_INFO.city
  is '所属城市';
comment on column D_MATCH_APPLY_INFO.detail_address
  is '详细地址';
comment on column D_MATCH_APPLY_INFO.assembly_address
  is '集合地址';
comment on column D_MATCH_APPLY_INFO.assembly_date
  is '集合时间';
comment on column D_MATCH_APPLY_INFO.apply_phone
  is '手机号(给别人报名的)';
comment on column D_MATCH_APPLY_INFO.match_code
  is '赛事类型码值  1宁夏赛事   2青岛赛事  3志愿者报名';
-- Create/Recreate indexes 
create index ASDFDSDF on D_MATCH_APPLY_INFO (TEAM_ID, MATCH_ID)
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index MATCH_USERPHONE on D_MATCH_APPLY_INFO (MATCH_ID, USER_PHONE)
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index TEMAUSERPHONE on D_MATCH_APPLY_INFO (MATCH_ID, TEAM_ID, USER_PHONE)
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_APPLY_INFO
  add primary key (ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  
  -- Create table
create table D_MATCH_INFO
(
  match_id               VARCHAR2(40) not null,
  match_type_id          VARCHAR2(40) not null,
  match_group_id         VARCHAR2(40) not null,
  match_name             VARCHAR2(40),
  match_des              BLOB,
  match_address          VARCHAR2(100),
  match_photo            VARCHAR2(100),
  match_apply_start_time CHAR(19),
  match_apply_end_time   CHAR(19),
  match_start_time       CHAR(19),
  match_end_time         CHAR(19),
  match_pay_flag         CHAR(1) default 0,
  match_pay_money        NUMBER(11,2),
  match_pay_mer_id       VARCHAR2(40),
  match_insure_flag      CHAR(1) default 0,
  match_insure_money     NUMBER(11,2),
  match_insure_mer_id    VARCHAR2(40),
  match_type             CHAR(1) default 0,
  match_num_limit        NUMBER(6),
  match_group_limit      NUMBER(6),
  match_group_num_limit  NUMBER(6),
  match_apply_param      VARCHAR2(300),
  match_vote_flag        CHAR(1) default 0,
  match_state            CHAR(1) default 0,
  match_notice           BLOB,
  match_rules            BLOB,
  match_attention        BLOB,
  match_photo_detail     VARCHAR2(100),
  match_gender_flag      CHAR(1) default 0,
  match_age_flag         CHAR(1) default 0,
  match_max_age          NUMBER(3),
  match_min_age          NUMBER(3),
  match_stock_num        NUMBER(6),
  match_group_max_limit  NUMBER(6),
  match_create_time      VARCHAR2(20),
  match_sponsor          VARCHAR2(100),
  match_tp               VARCHAR2(2),
  match_des_title        VARCHAR2(1000),
  match_notice_title     VARCHAR2(1000),
  match_rules_title      VARCHAR2(1000),
  match_attention_title  VARCHAR2(1000),
  match_check_state      VARCHAR2(2),
  match_check_name       VARCHAR2(100),
  match_check_time       VARCHAR2(20),
  match_check_des        VARCHAR2(100),
  match_create_name      VARCHAR2(100),
  match_deal_flag        CHAR(1) default 0,
  match_code             VARCHAR2(2),
  match_finals_flag      CHAR(1) default 0,
  match_pre_id           VARCHAR2(40)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_INFO
  is '赛事信息表';
-- Add comments to the columns 
comment on column D_MATCH_INFO.match_id
  is '赛事id';
comment on column D_MATCH_INFO.match_type_id
  is '	赛事类型(大项Id)';
comment on column D_MATCH_INFO.match_group_id
  is '	赛事组别(小项Id）';
comment on column D_MATCH_INFO.match_name
  is '赛事名称';
comment on column D_MATCH_INFO.match_des
  is '赛事简介';
comment on column D_MATCH_INFO.match_address
  is '赛事地址';
comment on column D_MATCH_INFO.match_photo
  is '赛事图片地址';
comment on column D_MATCH_INFO.match_apply_start_time
  is '	报名开始时间';
comment on column D_MATCH_INFO.match_apply_end_time
  is '	报名截止时间';
comment on column D_MATCH_INFO.match_start_time
  is '赛事开始时间';
comment on column D_MATCH_INFO.match_end_time
  is '赛事截止时间';
comment on column D_MATCH_INFO.match_pay_flag
  is '是否有报名费用   1是  0否';
comment on column D_MATCH_INFO.match_pay_money
  is '报名费用';
comment on column D_MATCH_INFO.match_pay_mer_id
  is '报名费商户ID';
comment on column D_MATCH_INFO.match_insure_flag
  is '是否必须购买保险   1是  0否   2:不需要购买保险';
comment on column D_MATCH_INFO.match_insure_money
  is '保险费用';
comment on column D_MATCH_INFO.match_insure_mer_id
  is '保险费商户ID';
comment on column D_MATCH_INFO.match_type
  is ' 0 个人赛   1团队赛';
comment on column D_MATCH_INFO.match_num_limit
  is '人数限制';
comment on column D_MATCH_INFO.match_group_limit
  is '队伍限制限制';
comment on column D_MATCH_INFO.match_group_num_limit
  is '队伍达标人数限制';
comment on column D_MATCH_INFO.match_apply_param
  is '报名采集信息';
comment on column D_MATCH_INFO.match_vote_flag
  is ' 0 不开启   1开启';
comment on column D_MATCH_INFO.match_state
  is '1上线  0下线 ';
comment on column D_MATCH_INFO.match_notice
  is '报名须知';
comment on column D_MATCH_INFO.match_rules
  is '赛事规程';
comment on column D_MATCH_INFO.match_attention
  is '注意事项';
comment on column D_MATCH_INFO.match_photo_detail
  is '列表对应的详情图片';
comment on column D_MATCH_INFO.match_gender_flag
  is '0 没有限制  1 男  2女';
comment on column D_MATCH_INFO.match_age_flag
  is '0 没有限制  1有限制';
comment on column D_MATCH_INFO.match_max_age
  is '年龄最大限制';
comment on column D_MATCH_INFO.match_min_age
  is '年龄最小限制';
comment on column D_MATCH_INFO.match_stock_num
  is '剩余人数限制';
comment on column D_MATCH_INFO.match_group_max_limit
  is '队伍最多人数限制';
comment on column D_MATCH_INFO.match_create_time
  is '赛事创建时间';
comment on column D_MATCH_INFO.match_sponsor
  is '赛事主办方';
comment on column D_MATCH_INFO.match_tp
  is '赛事项目类型   S 单项  I 趣味 P展演 ';
comment on column D_MATCH_INFO.match_des_title
  is '赛事简介标题';
comment on column D_MATCH_INFO.match_notice_title
  is '报名须知标题';
comment on column D_MATCH_INFO.match_rules_title
  is '赛事规程标题';
comment on column D_MATCH_INFO.match_attention_title
  is '注意事项';
comment on column D_MATCH_INFO.match_check_state
  is '审核状态   0 待审核    1  审核通过  2 审核不通过';
comment on column D_MATCH_INFO.match_check_name
  is '审核人名称';
comment on column D_MATCH_INFO.match_check_time
  is '审核时间';
comment on column D_MATCH_INFO.match_check_des
  is '审核原因';
comment on column D_MATCH_INFO.match_create_name
  is '创建人';
comment on column D_MATCH_INFO.match_deal_flag
  is '团体赛，定时处理组队中的状态，执行完标记为  1';
comment on column D_MATCH_INFO.match_code
  is '赛事类型码值  1宁夏赛事   2青岛赛事  3志愿者报名';
comment on column D_MATCH_INFO.match_finals_flag
  is '0 常规赛 1 预赛 2 决赛';
comment on column D_MATCH_INFO.match_pre_id
  is '预赛赛事ID';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_INFO
  add constraint MATCHID unique (MATCH_ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  -- Create table
create table D_MATCH_COMMON_INFO
(
  match_common_id     VARCHAR2(40),
  match_common_name   VARCHAR2(100),
  match_common_param  VARCHAR2(100),
  match_common_flag   VARCHAR2(2),
  match_common_param1 VARCHAR2(100)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_COMMON_INFO
  is '赛事通用表';
-- Add comments to the columns 
comment on column D_MATCH_COMMON_INFO.match_common_id
  is '赛事通用id';
comment on column D_MATCH_COMMON_INFO.match_common_name
  is '赛事通用名称';
comment on column D_MATCH_COMMON_INFO.match_common_param
  is '赛事通用参数';
comment on column D_MATCH_COMMON_INFO.match_common_flag
  is '赛事通用状态  0开启 1关闭';
comment on column D_MATCH_COMMON_INFO.match_common_param1
  is '赛事通用参数1';

  
  -- Create table
create table D_MATCH_MAXTERM
(
  match_max_id      VARCHAR2(40) not null,
  match_max_name    VARCHAR2(40) not null,
  match_max_detail  VARCHAR2(100),
  match_max_type_id VARCHAR2(40),
  match_detail      BLOB
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_MAXTERM
  is '赛事大项表';
-- Add comments to the columns 
comment on column D_MATCH_MAXTERM.match_max_id
  is '赛事大项id';
comment on column D_MATCH_MAXTERM.match_max_name
  is '赛事大项名称';
comment on column D_MATCH_MAXTERM.match_max_detail
  is '赛事大项详情';
comment on column D_MATCH_MAXTERM.match_max_type_id
  is '赛事大项类型id';
comment on column D_MATCH_MAXTERM.match_detail
  is '赛事详情';

  
  -- Create table
create table D_MATCH_MINTERM
(
  match_min_id     VARCHAR2(40) not null,
  match_max_name   VARCHAR2(40) not null,
  match_min_detail VARCHAR2(100),
  match_max_id     VARCHAR2(40),
  match_tp         VARCHAR2(40),
  match_tp_name    VARCHAR2(40)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_MINTERM
  is '赛事小项表';
-- Add comments to the columns 
comment on column D_MATCH_MINTERM.match_min_id
  is '赛事小项id';
comment on column D_MATCH_MINTERM.match_max_name
  is '赛事大项名称';
comment on column D_MATCH_MINTERM.match_min_detail
  is '赛事小项详情';
comment on column D_MATCH_MINTERM.match_max_id
  is '赛事大项id';
comment on column D_MATCH_MINTERM.match_tp
  is '赛事类型';
comment on column D_MATCH_MINTERM.match_tp_name
  is '赛事类型名称';

  
  -- Create table
create table D_MATCH_TEAM_INFO
(
  team_id           VARCHAR2(32) not null,
  team_code         VARCHAR2(8) not null,
  match_id          VARCHAR2(32) not null,
  team_name         VARCHAR2(100) not null,
  team_header_name  VARCHAR2(20) not null,
  team_header_phone VARCHAR2(20) not null,
  team_state        CHAR(1) not null,
  team_num          VARCHAR2(6) not null,
  team_check_des    VARCHAR2(200),
  team_update_time  VARCHAR2(20),
  team_create_time  VARCHAR2(20),
  team_logo         VARCHAR2(2000),
  login_name        VARCHAR2(20)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the columns 
comment on column D_MATCH_TEAM_INFO.team_id
  is '队伍id';
comment on column D_MATCH_TEAM_INFO.team_code
  is '队伍编码 用于分享';
comment on column D_MATCH_TEAM_INFO.match_id
  is '赛事id';
comment on column D_MATCH_TEAM_INFO.team_name
  is '队伍名称';
comment on column D_MATCH_TEAM_INFO.team_header_name
  is '队长名称';
comment on column D_MATCH_TEAM_INFO.team_header_phone
  is '队长手机号';
comment on column D_MATCH_TEAM_INFO.team_state
  is '队伍状态 0:待审核 1:组队中 2:组队成功 3:已解散 4:审核失败  5:创建队伍';
comment on column D_MATCH_TEAM_INFO.team_num
  is '队伍最大人数';
comment on column D_MATCH_TEAM_INFO.team_check_des
  is '审核原因';
comment on column D_MATCH_TEAM_INFO.team_update_time
  is '审核时间';
comment on column D_MATCH_TEAM_INFO.team_create_time
  is '队伍创建时间';
comment on column D_MATCH_TEAM_INFO.team_logo
  is '队伍logo';
comment on column D_MATCH_TEAM_INFO.login_name
  is '登录名';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_TEAM_INFO
  add primary key (TEAM_ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  -- Create table
create table D_MATCH_TEAM_INFO
(
  team_id           VARCHAR2(32) not null,
  team_code         VARCHAR2(8) not null,
  match_id          VARCHAR2(32) not null,
  team_name         VARCHAR2(100) not null,
  team_header_name  VARCHAR2(20) not null,
  team_header_phone VARCHAR2(20) not null,
  team_state        CHAR(1) not null,
  team_num          VARCHAR2(6) not null,
  team_check_des    VARCHAR2(200),
  team_update_time  VARCHAR2(20),
  team_create_time  VARCHAR2(20),
  team_logo         VARCHAR2(2000),
  login_name        VARCHAR2(20)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the columns 
comment on column D_MATCH_TEAM_INFO.team_id
  is '队伍id';
comment on column D_MATCH_TEAM_INFO.team_code
  is '队伍编码 用于分享';
comment on column D_MATCH_TEAM_INFO.match_id
  is '赛事id';
comment on column D_MATCH_TEAM_INFO.team_name
  is '队伍名称';
comment on column D_MATCH_TEAM_INFO.team_header_name
  is '队长名称';
comment on column D_MATCH_TEAM_INFO.team_header_phone
  is '队长手机号';
comment on column D_MATCH_TEAM_INFO.team_state
  is '队伍状态 0:待审核 1:组队中 2:组队成功 3:已解散 4:审核失败  5:创建队伍';
comment on column D_MATCH_TEAM_INFO.team_num
  is '队伍最大人数';
comment on column D_MATCH_TEAM_INFO.team_check_des
  is '审核原因';
comment on column D_MATCH_TEAM_INFO.team_update_time
  is '审核时间';
comment on column D_MATCH_TEAM_INFO.team_create_time
  is '队伍创建时间';
comment on column D_MATCH_TEAM_INFO.team_logo
  is '队伍logo';
comment on column D_MATCH_TEAM_INFO.login_name
  is '登录名';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_TEAM_INFO
  add primary key (TEAM_ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
  
  -- Create table
create table D_MATCH_MAXTYPE
(
  match_max_type_id   VARCHAR2(40) not null,
  match_max_type_name VARCHAR2(100) not null,
  match_create_time   VARCHAR2(20)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_MAXTYPE
  is '赛事类型表';
-- Add comments to the columns 
comment on column D_MATCH_MAXTYPE.match_max_type_id
  is '赛事类型id';
comment on column D_MATCH_MAXTYPE.match_max_type_name
  is '赛事类型名称';
comment on column D_MATCH_MAXTYPE.match_create_time
  is '创建时间';

  
  -- Create table
create table D_MATCH_ROTATION_CHART_INFO
(
  match_id        VARCHAR2(40) not null,
  match_seq       VARCHAR2(5) not null,
  match_state     VARCHAR2(5) not null,
  match_picture   VARCHAR2(100) not null,
  match_jump_url  VARCHAR2(100),
  match_jump_flag VARCHAR2(5) not null
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_ROTATION_CHART_INFO
  is '赛事轮播图表';
-- Add comments to the columns 
comment on column D_MATCH_ROTATION_CHART_INFO.match_id
  is '赛事轮播id';
comment on column D_MATCH_ROTATION_CHART_INFO.match_seq
  is '赛事轮播排序';
comment on column D_MATCH_ROTATION_CHART_INFO.match_state
  is '赛事轮播状态 0 启用 1禁用';
comment on column D_MATCH_ROTATION_CHART_INFO.match_picture
  is '赛事轮播地址';
comment on column D_MATCH_ROTATION_CHART_INFO.match_jump_url
  is '赛事轮播跳转地址';
comment on column D_MATCH_ROTATION_CHART_INFO.match_jump_flag
  is '赛事轮播跳转开关  0 无跳转 1跳转';

  
  -- Create table
create table D_MATCH_REGISTER
(
  user_phone VARCHAR2(11) not null,
  name       VARCHAR2(100),
  state      VARCHAR2(2)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_REGISTER
  is '赛事短信表';
-- Add comments to the columns 
comment on column D_MATCH_REGISTER.user_phone
  is '手机号';
comment on column D_MATCH_REGISTER.name
  is '姓名';
comment on column D_MATCH_REGISTER.state
  is '状态 01 待发送短信 02已发送短信 03已报名';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_REGISTER
  add constraint MATCH_KEY primary key (USER_PHONE)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  -- Create table
create table D_MATCH_TYPE_DETAIL_INFO
(
  match_type_detail_id VARCHAR2(40) not null,
  match_title          VARCHAR2(100) not null,
  match_type_id        VARCHAR2(64) not null,
  match_stick_flag     VARCHAR2(2) not null,
  match_details        BLOB,
  match_state          VARCHAR2(2) not null,
  match_create_time    VARCHAR2(20),
  match_subtitle       VARCHAR2(100)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_TYPE_DETAIL_INFO
  is '赛事资讯详情表';
-- Add comments to the columns 
comment on column D_MATCH_TYPE_DETAIL_INFO.match_type_detail_id
  is '赛事详情id';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_title
  is '赛事标题';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_type_id
  is '赛事资讯类型id';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_stick_flag
  is '是否置顶    0置顶  1不置顶';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_details
  is '赛事资讯内容';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_state
  is '赛事资讯状态    0开启   1关闭';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_create_time
  is '创建时间';
comment on column D_MATCH_TYPE_DETAIL_INFO.match_subtitle
  is '赛事副标题';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_TYPE_DETAIL_INFO
  add constraint MATCH_TYPE_DETAIL_ID primary key (MATCH_TYPE_DETAIL_ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  -- Create table
create table D_MATCH_TYPE_INFO
(
  match_type_id     VARCHAR2(40) not null,
  match_type_name   VARCHAR2(100) not null,
  match_type_flag   VARCHAR2(2) not null,
  match_create_time VARCHAR2(20)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_TYPE_INFO
  is '赛事资讯类型表';
-- Add comments to the columns 
comment on column D_MATCH_TYPE_INFO.match_type_id
  is '赛事类型id';
comment on column D_MATCH_TYPE_INFO.match_type_name
  is '赛事类型名称';
comment on column D_MATCH_TYPE_INFO.match_type_flag
  is '赛事资讯类型状态     0启用 1禁用';
comment on column D_MATCH_TYPE_INFO.match_create_time
  is '创建时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table D_MATCH_TYPE_INFO
  add constraint MATCH_TYPE_ID primary key (MATCH_TYPE_ID)
  using index 
  tablespace CSK_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

  
  -- Create table
create table D_MATCH_VOTE_INFO
(
  vote_id   VARCHAR2(64) not null,
  week_no   NUMBER(2) not null,
  team_id   VARCHAR2(40),
  user_id   VARCHAR2(40),
  user_nm   VARCHAR2(20),
  vote_num  NUMBER(2),
  vote_time CHAR(19),
  year_no   NUMBER(10)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_VOTE_INFO
  is '投票关系维护表';
-- Add comments to the columns 
comment on column D_MATCH_VOTE_INFO.vote_id
  is 'id主键';
comment on column D_MATCH_VOTE_INFO.week_no
  is '自然周数';
comment on column D_MATCH_VOTE_INFO.team_id
  is '队伍Id';
comment on column D_MATCH_VOTE_INFO.user_id
  is '投票人证件号(cert_id)';
comment on column D_MATCH_VOTE_INFO.user_nm
  is '投票人手机号';
comment on column D_MATCH_VOTE_INFO.vote_num
  is '投票数';
comment on column D_MATCH_VOTE_INFO.vote_time
  is 'yyyy-MM-dd HH:mm;ss';
comment on column D_MATCH_VOTE_INFO.year_no
  is '自然年数';

  
  -- Create table
create table D_MATCH_VOTE_NUM
(
  id                VARCHAR2(40) not null,
  week_no           NUMBER(2) not null,
  user_id           VARCHAR2(40),
  user_nm           VARCHAR2(40),
  card_type         CHAR(1),
  card_no           VARCHAR2(40),
  vote_num          NUMBER(2),
  left_vote_num     NUMBER(2),
  balance_one       NUMBER(10,2) default +0.00,
  creat_time        VARCHAR2(19),
  balance_two       NUMBER(10,2) default +0.00,
  update_time       VARCHAR2(19),
  balance_three     NUMBER(10,2) default +0.00,
  update_time_three VARCHAR2(19),
  vote_id_one       VARCHAR2(40),
  vote_id_two       VARCHAR2(40),
  vote_id_three     VARCHAR2(40),
  year_no           VARCHAR2(10)
)
tablespace CSK_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table D_MATCH_VOTE_NUM
  is '投票次数统计表';
-- Add comments to the columns 
comment on column D_MATCH_VOTE_NUM.id
  is '主键Id';
comment on column D_MATCH_VOTE_NUM.week_no
  is '自然周数';
comment on column D_MATCH_VOTE_NUM.user_id
  is '投票人证件号(cert_id)';
comment on column D_MATCH_VOTE_NUM.user_nm
  is '投票人手机号';
comment on column D_MATCH_VOTE_NUM.card_type
  is '投票卡类型  ';
comment on column D_MATCH_VOTE_NUM.card_no
  is '投票卡号';
comment on column D_MATCH_VOTE_NUM.vote_num
  is '本周投票总数';
comment on column D_MATCH_VOTE_NUM.left_vote_num
  is '本周已用票数';
comment on column D_MATCH_VOTE_NUM.balance_one
  is '借记卡首次记录余额';
comment on column D_MATCH_VOTE_NUM.creat_time
  is '记录日期';
comment on column D_MATCH_VOTE_NUM.balance_two
  is '借记卡第二次记录余额';
comment on column D_MATCH_VOTE_NUM.update_time
  is '更新日期';
comment on column D_MATCH_VOTE_NUM.balance_three
  is '借记卡第三次记录余额';
comment on column D_MATCH_VOTE_NUM.update_time_three
  is '第二次增加投票数记录日期';
comment on column D_MATCH_VOTE_NUM.vote_id_one
  is '投票数据维护表Id，记录对应关系';
comment on column D_MATCH_VOTE_NUM.vote_id_two
  is '投票数据维护表Id，记录对应关系';
comment on column D_MATCH_VOTE_NUM.vote_id_three
  is '投票数据维护表Id，记录对应关系';
comment on column D_MATCH_VOTE_NUM.year_no
  is '自然年数';

